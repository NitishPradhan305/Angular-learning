let demo = "elephant";
console.log(demo[4]);
n = demo.length;
console.log(n);
console.log(demo[n]);