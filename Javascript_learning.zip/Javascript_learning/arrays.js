let names = ["Nitish","Suraj","Mohan","Mihir"];
console.log(typeof names);
console.log(names);
console.log(names[1]);
names[1]="Denim";
console.log(names);
console.log(Array.isArray(names));
let play = {};  //Object literal
console.log(Array.isArray(play));
let laugh = ["kite",2,78.4,null,undefined];
console.log(laugh);
console.log(laugh.length);