let day = 4;

switch (day) {
    case 0:
        console.log("entered zero");
        break;
    case 1:
        console.log("entered 1");
        break;
    case 2:
        console.log("entered 2");
        break;
    case 3:
        console.log("entered 3");
        break;
    case 4:
        console.log("entered 4");
        break;
    case 5:
        console.log("entered 5");
        break;
    default:
        console.log("entered nothing");
}