const key1 = "objkey1";
const key2 = "objkey2";

const value1 = "myValue1";
const value2 = "myValue2";

const person = {
     [key1] : value1,     //This is called
     [key2] : value2      //Computed properties
}
console.log(person);

// const person = {};
// person[key1]=value1;
// person[key2]=value2;
// console.log(person);
