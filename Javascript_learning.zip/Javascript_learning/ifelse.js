let x=null;

if (x) {
    console.log("You are here");
} else {
    console.log("it is a falsy value");
}

//falsy values
//false
//null
//undefined
//""
//0

let demo;
if (demo) {
    console.log("----------")
} else {
    console.log("undefined is a falsy value");
}