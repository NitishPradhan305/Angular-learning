const array1 = ["A","B","C","D"];
// array1 = [];    //Uncaught typeeerror
array1.push("Nitish");
console.log("Use of const");
console.log(array1);

let names = ["nko","rko"];
names = [];
names.push("Me");
console.log(names);