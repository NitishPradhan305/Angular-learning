// We cannot change the value of const
const h= 90;
console.log(h*4);