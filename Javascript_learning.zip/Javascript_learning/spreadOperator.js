let array1 = ["item1","item2"];
let array2 = ["item3","item4"];
let arraysum = [...array1,...array2];
console.log(arraysum);