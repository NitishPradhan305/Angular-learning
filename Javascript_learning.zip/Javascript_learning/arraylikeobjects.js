//Array like objects
//Jinka length find kiya ja sakta hai use array like objects kehte hain
//Jinka index se value nikala ja sakta hai 

const name = "Nitish kumar Pradhan";
console.log(name.length);
console.log(name[5]);
