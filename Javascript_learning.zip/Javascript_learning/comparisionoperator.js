let num1 = "78";
let num2 = 78;
console.log(num1>num2);
console.log(num1==num2);
console.log(num1===num2);

console.log(num1!=num2);
console.log(num1!==num2);
