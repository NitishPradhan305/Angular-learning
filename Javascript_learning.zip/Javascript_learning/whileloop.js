let k = 0;
let sum = 0;
// while(k>0){
//     console.log(k);
//     k--;
// }

while(k<9){
sum = sum + k;
k++;
}
console.log(`Sum is : ${sum}`)