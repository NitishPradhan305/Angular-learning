let str1 = "Nitish";
let str2 = "Pradhan";
console.log(str1+str2);

let str3 = "17";
let str4 = "89";
console.log(+str3+(+str4));