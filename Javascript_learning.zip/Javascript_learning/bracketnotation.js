const key = "skill";
const person = {
    name : "Nitish",
    age : "26",
    "address home" : "Jharkhand"
}
console.log(person);
console.log(person["address home"]);
person[key]= "Player";
console.log(person);