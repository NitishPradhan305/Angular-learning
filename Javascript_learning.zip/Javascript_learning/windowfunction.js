//Window
function cricket(){
    console.log(this);
}
cricket();