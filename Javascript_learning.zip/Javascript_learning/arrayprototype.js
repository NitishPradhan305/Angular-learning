//Array prototype 

const numbers = new Array("hello","Mike","John");
// console.log(Object.getPrototypeOf(numbers));
console.log(Array.prototype);