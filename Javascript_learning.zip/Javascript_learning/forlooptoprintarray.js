let names = ["Nitish","Kumar","Pradhan"];
let array1 = [];
for (let index = 0; index < names.length; index++) {
    array1.push(names[index].toUpperCase());
}
console.log(array1);