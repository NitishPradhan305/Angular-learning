let names = ["Nitish","Suraj","Mohan","Mihir"];
//Push opertions
console.log(names);
names.push("Hello");
console.log(names);

//Pop Operations
let demo = names.pop();
console.log(names);
console.log("Popped element is : - "+ demo);
