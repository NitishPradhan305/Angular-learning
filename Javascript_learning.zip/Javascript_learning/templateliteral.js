let str = "Nitish Pradhan";
let str2 = "25";
console.log(`My name is ${str} and my age is ${str2}`)


let myVariable = null;
// myVariable = "Nitish";
console.log(typeof myVariable);

let num = 8967576766;
console.log(Number.MAX_SAFE_INTEGER)

//BigInt summation
let k = BigInt(5779855345243766980887643);
let m = 765n;
console.log(k+m)