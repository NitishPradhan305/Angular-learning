const names = ["Nitish","Mohan","Karan","Sam"];
const array1 = [];
for (let name of names) {
    array1.push(name.toUpperCase());
}
console.log(array1);