//function expresion
const sumtwonumbers = function(number1,number2){
    return number1+number2;
}
console.log(sumtwonumbers(5,6));

//example 2
const isEven = function(number3){
    return number3 % 2 == 0 ;
}
console.log(isEven(7));

//example 3
const  findlength = function(str){
    return str.length;
}
console.log(findlength("Nitish"));