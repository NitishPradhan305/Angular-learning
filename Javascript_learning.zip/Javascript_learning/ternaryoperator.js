let age = 24;
let play = age>=18 ? "mobile" : "cylce";
console.log(play);