"use strict";

let firstName = "Nitish";
 firstName = "Mohan";
console.log(firstName);