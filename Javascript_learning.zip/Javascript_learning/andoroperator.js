let car = "Maruti";
let rate= 50;
if (car[0]==="M" && rate>40) {
    console.log("Inside if")
} else {
    console.log("Inside else");
}

if (car[0]==="j" || rate>30) {
    console.log("Inside if");
} else {
    console.log("Inside else");
}
