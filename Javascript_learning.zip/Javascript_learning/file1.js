console.log("Hello world");
console.log("Nitish");
console.log("Keep your eyes there");
console.log("you are going to learn javascript");
console.log('Nitish is here');
console.log(`You must continue learining`)
var ke = "of Nitish";
console.log(`today is the second day ${ke} `)