let firstName = "   Mike     ";
console.log(firstName.length);

demoStat = firstName.trim();
console.log(demoStat);
console.log(demoStat.toUpperCase());

//trim()
//toUppperCase()
//toLowerCase()
//slice()

let test = "NitishKumarPradhan";
let n = test.slice(0,7);
console.log(n);