
let i = 7;
do {
    console.log(i);
i++;
} while (i<10);