let sum = 0 ;
for (let index = 0; index < 18; index++) {
    sum = sum + index;
}
console.log(sum);
console.log(index);
