
//Primitive data types
let num1 = 7;
let num2 = num1;
console.log(num1);
console.log(num2);

num1++;
console.log(num1);
console.log(num2);

//Reference data types
let array1 = ["nelson","Bhola","King"];
let array2 = array1;
console.log(array1);
console.log(array2);
console.log("-----------------");
array1.push("kite");
console.log(array1);
console.log(array2);