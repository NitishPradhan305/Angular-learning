let names = ["Mike","Carl","John","Peter"];
console.log(names);

//Unshift Opertion
names.unshift("Nitish");
names.unshift("Suraj");
names.unshift("Goldy");
names.unshift("Modern");
console.log(names);

//Shift Opertion
let demo = names.shift();
console.log(`removed element from the first is :- ${demo}`);
console.log(names);