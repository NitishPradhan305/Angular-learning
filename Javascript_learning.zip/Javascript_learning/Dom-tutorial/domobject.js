//Dom object - (Document)
const uniqueId2 = document.getElementById("SiteName");
console.log(uniqueId2.textContent);
uniqueId2.textContent = "You can change content";
console.log(uniqueId2.textContent);
