//write a function to add two numbers
const hello = function(){
    return 4;
}

console.log(hello());