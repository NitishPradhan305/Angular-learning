const navItems = document.getElementsByClassName("nav-item");
console.log(navItems[2]);

//We can not use foreach loop to iterate HTML Collection items
