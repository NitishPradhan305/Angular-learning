const h1 = document.querySelector("h1");
console.log(h1);
const body = h1.parentElement.parentElement;
console.log(body);
body.style.backgroundColor = "Blue";
body.style.color = "White";
