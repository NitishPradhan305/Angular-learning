
const mainHeading = document.querySelector("#SiteName");
console.log(mainHeading.style);
mainHeading.style.color = "Green";





