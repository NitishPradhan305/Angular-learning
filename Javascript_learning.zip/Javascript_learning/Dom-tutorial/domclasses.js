const sectionTodo = document.querySelector(".section-todo");
console.log(sectionTodo.classList);
