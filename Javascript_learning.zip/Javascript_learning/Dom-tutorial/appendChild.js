const ul = document.querySelector(".todo-list");
const li = document.createElement("li");
li.textContent = "Nitish";
ul.appendChild(li);
console.log(ul);