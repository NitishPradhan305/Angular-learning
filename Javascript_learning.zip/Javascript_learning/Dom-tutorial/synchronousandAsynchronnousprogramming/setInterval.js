//Use of setInterval
//Your code will keep up repeating itself after running all the codes


console.log("your code starts here");

setInterval(()=>{
    console.log("***********");
},500);

console.log("Your code ends here. ");