//Use of innerHtml in js
const demoObject = document.querySelector(".form-inline");
console.log(demoObject);
console.log(demoObject.innerHTML);
demoObject.innerHTML = "You have changed the content using inner HTML";
console.log(demoObject.innerHTML);






